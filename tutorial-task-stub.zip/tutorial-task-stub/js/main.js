class MainScene extends Phaser.Scene {
    //global variales
    camera;
    player;
    floor;

    constructor(){
        super("MainScene")
    }
    preload(){
        //loads in the json from tiled for level 
        this.load.tilemapTiledJSON('level1', 'assets/map.json');
        //loads in the tileset for level
        this.load.image("kenney-tileset", "assets/kenney-tileset-64px-extruded.png");
        
    }

    create(){
        const map = this.make.tilemap({key: 'level1'});
        this.matter.world.setBounds(0,0,map.widthInPixels,map.heightInPixels);
        const tileset = map.addTilesetImage('kenney-tileset', 'kenney-tileset');
        //background layer
        this.background = map.createLayer('background', tileset, 0, 0);
        this.matter.world.convertTilemapLayer(this.background);
        //ground layer
        this.land = map.createLayer('ground', tileset, 0, 0);
        this.land.setCollisionBetween(1,1000);
        this.matter.world.convertTilemapLayer(this.land);

        //physics objects
        
    }

    update(){

    }
}