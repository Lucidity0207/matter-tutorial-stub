class MainScene extends Phaser.Scene {
    //global variales

    constructor(){
        super("MainScene")
    }
    preload(){
    }

    create(){
        //matter engine and renderer
        let engine = Matter.Engine.create();

        let render = Matter.Render.create({
            element: document.body,
            engine:engine,
            options: {
                width: 500,
                height: 500,
                wireframes: false
            }
        });
        Matter.Engine.run(engine);
        Matter.Render.run(render);
    }

    update(){

    }
}